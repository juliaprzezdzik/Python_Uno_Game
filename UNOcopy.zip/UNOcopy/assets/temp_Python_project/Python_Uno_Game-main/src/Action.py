from GameState import GameState

class Action:
    def __init__(self, state):
        self.game_state = state
        self.n_actions = self.game_state.player_cards_count + 1

    def permorm_action(self, game, action, state):
        reward = 0
        #stan przed wykonaniem akcji
        prev_state = state
        if action >= game.players[1].count_cards_in_hand():
            game.draw_card(0)
            reward = -1
        elif game.play_card(1, action):
            card_played = game.deck.get_top_discarded_card()
            if card_played.value == "Draw Two":
                reward += 2
            elif card_played.value == "Wild Draw Four":
                reward += 4
            elif card_played.value == "Skip":
                reward += 1
            elif card_played.value == "Wild":
                reward += 3

            if game.is_color_changed:
                game.change_color(state.most_common_color)
            reward = 5 #nagroda za poprawny ruch
        else:
            reward = -10 #kara za nielegalny ruch
        if game.check_winner() == game.players[1]:
            reward += 100
        elif game.check_winner() == game.players[0]:
            reward -= 100

        next_game_state = GameState(game)
        next_state = next_game_state
        action_effectiveness = self.calculate_action_effectiveness(prev_state, next_state)
        reward += action_effectiveness
        return reward
    
    def calculate_action_effectiveness(self, prev_state, next_state):
        prev_score = self.calculate_state_score(prev_state)
        next_score = self.calculate_state_score(next_state)
        effectiveness = next_score - prev_score
        if effectiveness > 0:
            return 1
        elif effectiveness < 0:
            return -1
        else:
            return 0
        
    def calculate_state_score(self, state):
        player_cards_count = state.player_cards_count
        opponent_cards_count = state.opponent_cards_count
        plus_four = state.number_plus_four
        plus_two = state.number_plus_four
        wild = state.number_wild
        skip = state.number_skip 
        score = (opponent_cards_count - player_cards_count) + (2 * plus_two) + (3 * wild) + (4 * plus_four) + skip
        return score
    







