from Game import Game
from GameState import GameState
from Action import Action
from Model import DQN, Agent

BATCH_SZE = 128
GAMMA = 0.99
EPS_START = 0.9
EPS_END = 0.05
EPS_DECAY = 1000
TAU = 0.005
LR = 1e-4

def train(game):
    game.start_game()
    game_state = GameState(game)
    game_action = Action(game_state)
    n_observations = len(game_state.encode_state())
    n_actions = game_action.n_actions

    policy_net = DQN(n_observations, n_actions).to(device)



