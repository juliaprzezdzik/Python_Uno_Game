import torch as T
import torch.nn.functional as F
import numpy as np
from Model import DQN  # Twój model sieci neuronowej
from ReplayBuffer import ReplayBuffer
import random

class DQNAgent():
    def __init__(self, n_actions, input_dims, learning_rate, gamma, epsilon, epsilon_min, epsilon_decay, buffer_size, batch_size):
        self.n_actions = n_actions
        self.gamma = gamma
        self.epsilon = epsilon
        self.epsilon_min = epsilon_min
        self.epsilon_decay = epsilon_decay
        self.batch_size = batch_size

        self.memory = ReplayBuffer(buffer_size)
        self.model = DQN(learning_rate, input_dims, 128, 128, n_actions)
        self.optimizer = T.optim.Adam(self.model.parameters(), lr=learning_rate)
        self.loss = T.nn.MSELoss()

    def choose_action(self, state, available_actions):
        if np.random.random() < self.epsilon:  # Eksploracja
            return random.choice(available_actions)
        else:  
            state_tensor = T.tensor(state, dtype=T.float).unsqueeze(0)
            q_values = self.model(state_tensor)
            mask = T.full_like(q_values, -float('inf'))
            mask[0, available_actions] = q_values[0, available_actions]
            return T.argmax(mask).item()

    def store_experience(self, state, action, reward, next_state, done):
        self.memory.store(state, action, reward, next_state, done)

    def learn(self):
        if self.memory.size() < self.batch_size:
            return

        # Pobierz próbki z Replay Buffer
        states, actions, rewards, next_states, dones = self.memory.sample(self.batch_size)
        states = T.tensor(states, dtype=T.float)
        actions = T.tensor(actions, dtype=T.long)
        rewards = T.tensor(rewards, dtype=T.float)
        next_states = T.tensor(next_states, dtype=T.float)
        dones = T.tensor(dones, dtype=T.bool)

        q_pred = self.model(states).gather(1, actions.unsqueeze(-1)).squeeze(-1)
        q_next = self.model(next_states).max(1)[0]
        q_target = rewards + self.gamma * q_next * (~dones)

        loss = self.loss(q_pred, q_target)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay


        