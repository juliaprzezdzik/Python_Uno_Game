class GameState:
    def __init__(self, game):
        self.game = game
        player = game.players[1]
        self.player_cards_count = player.count_cards_in_hand()
        self.opponent_cards_count = game.players[0].count_cards_in_hand()
        self.cards_in_hand = player.cards_in_hand      
        specials_cards = player.count_special_cards()
        self.number_plus_two = specials_cards["Draw Two"]
        self.number_plus_four = specials_cards["Wild Draw Four"]
        self.number_skip = specials_cards["Skip"]
        self.number_wild = specials_cards["Wild"]
        colors = player.count_color()
        self.numb_red = colors.get("Red", 0)
        self.numb_blue = colors.get("Blue", 0)
        self.numb_yellow = colors.get("Yellow", 0)
        self.numb_green = colors.get("Green", 0)
        self.numb_all = colors.get("All", 0)
        self.most_common_color = player.get_most_common_color()
        current_card = game.deck.get_top_discarded_card()
        if current_card:
            self.current_color = current_card.color
            self.current_value = current_card.value
        else:
            self.current_color = None
            self.current_value = None
    
    #zakodowany stan do postaci wektora, gotowy do pobrania przez agenta
    # def encode_state(self):
    #     color_mapping = {"Red" : 0, "Blue" : 1, "Yellow" : 2, "Green" : 3, "All" : 5}
    #     value_mapping = {"0" : 0, "1" : 1, "2": 2, "3" : 3, "4" : 4, "5" : 5, "6" : 6, 
    #                     "7" : 7, "8" : 8, "9" : 9, "Skip" : 10, "Draw Two" : 11, "Wild" : 12, "Wild Draw Four": 13}
        
    #     current_color = color_mapping.get(self.current_color, -1)
    #     current_value = value_mapping.get(self.current_value, -1)
    #     #[[wartosc, kolor], [wartosc, kolor], [...], ...]
    #     temp_player_hand = [[value_mapping[card.value], color_mapping[card.color]] for card in self.cards_in_hand]      
    #     #[wartosc, kolor, wartosc, kolor, ...]
    #     player_hand = [values for card in temp_player_hand for values in card]
    #     return[
    #         self.player_cards_count,
    #         self.opponent_cards_count,
    #         self.number_plus_two,
    #         self.number_plus_four,
    #         self.number_skip,
    #         self.number_wild,
    #         self.numb_red,
    #         self.numb_blue,
    #         self.numb_yellow,
    #         self.numb_green,
    #         self.numb_all,
    #         self.most_common_color,
    #         current_color,
    #         current_value,
    #         *player_hand #lista kart w rece
    #     ]
    def encode_state(self):
        color_mapping = {"Red": 0, "Blue": 1, "Yellow": 2, "Green": 3, "All": 4}
        value_mapping = {
            "0": 0, "1": 1, "2": 2, "3": 3, "4": 4,
            "5": 5, "6": 6, "7": 7, "8": 8, "9": 9,
            "Skip": 10, "Draw Two": 11, "Wild": 12, "Wild Draw Four": 13
        }

        # Zakodowanie koloru i wartości bieżącej karty na stosie
        current_color = color_mapping.get(self.current_color, -1)  # Domyślnie -1, jeśli brak karty
        current_value = value_mapping.get(self.current_value, -1)

        # Lista kart w ręce jako [[wartość, kolor], ...]
        temp_player_hand = [
            [value_mapping[card.value], color_mapping[card.color]]
            for card in self.cards_in_hand
        ]

        # Spłaszczenie listy kart w ręce
        player_hand = sum(temp_player_hand, [])  # Przekształcenie w jednowymiarową listę
        while len(player_hand) < 108:
            player_hand.append(0)

        # Zakodowany stan gry jako lista liczb
        return [
            self.player_cards_count,
            self.opponent_cards_count,
            self.number_plus_two,
            self.number_plus_four,
            self.number_skip,
            self.number_wild,
            self.numb_red,
            self.numb_blue,
            self.numb_yellow,
            self.numb_green,
            self.numb_all,
            current_color,
            current_value,
            *player_hand,  # Rozwinięcie listy kart w ręce
        ]
