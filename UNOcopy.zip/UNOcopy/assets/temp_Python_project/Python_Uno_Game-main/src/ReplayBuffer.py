# from collections import deque
# import random

# class ReplayBuffer:
#     def __init__(self, max_size):
#         self.buffer = deque(maxlen=max_size)

#     def store(self, state, action, reward, next_state, done):
#         self.buffer.append((state, action, reward, next_state, done))

#     def sample(self, batch_size):
#         batch = random.sample(self.buffer, batch_size)
#         states, actions, rewards, next_states, dones = zip(*batch)
#         return states, actions, rewards, next_states, dones

#     def size(self):
#         return len(self.buffer)
