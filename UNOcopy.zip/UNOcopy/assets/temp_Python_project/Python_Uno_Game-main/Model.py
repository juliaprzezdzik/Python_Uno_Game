# import torch as T
# import torch.nn as nn
# import torch.nn.functional as F
# import torch.optim as optim
# import numpy as np

# class DQN(nn.Module):
#     def __init__(self, learning_rate, game_state, fc1_dims, fc2_dims, n_actions):
#         super(DQN, self).__init__()
#         self.state = game_state.encode_state()
#         self.fc1_dims = fc1_dims
#         self.fc2_dims = fc2_dims
#         self.n_actions = n_actions
#         self.fc1 = nn.Linear(*self.state, self.fc1_dims)
#         self.fc2 = nn.Linear(*self.fc1_dims, self.fc2_dims)
#         self.fc3 = nn.Linear(*self.fc2_dims, self.n_actions)
#         self.optimizer = optim.Adam(self.parameters(), lr=learning_rate)
#         self.loss = nn.MSELoss()
#         self.device = T.devie('cuda:0' if T.cuda.is_available() else 'cpu')
#         self.to(self.device)

#     def forward(self, state):
#         x = F.relu(self.fc1(state))
#         x = F.relu(self.fc2(x))
#         actions = self.fc3(x)
#         return actions
    
# class Agent():
#     def __init__(self, gamma, epsilon, learning_rate, input_dims, batch_size, 
#                  n_actions, max_mem_size=100000, eps_end=0.01, eps_dec = 5e-4):
#         self.gamma = gamma #wsp. oceny nagrod
#         self.epsilon = epsilon #wsp.eksploracji
#         self.learning_rate = learning_rate #szybkosc uczenia sie dla optymalizatora
#         # self.input_dims = input_dims #wymiar zakodowanego stanu gry
#         self.eps_min = eps_end #minimalna wartosc epsilon
#         self.eps_dec = eps_dec #tempo zmiejszania epsilon

#         self.action_space = [i for i in range(n_actions)] #lista mozliwych akcji
#         self.mem_size = max_mem_size #maksymalny rozmiar bufora pamieci 
#         self.batch_size = batch_size #liczba probek
#         self.memory_counter = 0 #licznik przechowywanych doswiadczen
#         self.Q_eval = DQN(self.learning_rate, n_actions=n_actions, input_dims=input_dims, fc1_dims=256, fc2_dims=256)
        
#         #stany gry przed wykonaniem akcji
#         self.state_memory = np.zeros((self.mem_size, *input_dims), dtype=np.float32)
#         #stany gry po wykonaniu akcji
#         self.new_state_memory = np.zeros((self.mem_sizem *input_dims), dtype=np.float32)
#         self.action_memory = np.zeros(self.mem_size, dtype=np.float32)
#         self.reward_memory = np.zeros(self.mem_size, dtype=np.float32)
#         self.terminal_memory = np.zeros(self.mem_size, dtype=np.bool)

#         #przechowywanie jednego doswiadczenia
#     def store_transition(self, state, action, reward, new_stage, done):
#         index = self.memory_counter % self.mem_size #indeks doswiadczenia

#         #zapisywanie informacji do bufora
#         self.state_memory[index] = state
#         self.new_state_memory[index] = new_stage
#         self.reward_memory[index] = reward
#         self.action_memory[index] = action
#         self.terminal_memory[index] = done
#         self.memory_counter += 1

#     #wybor akcji -> epsilon-greedy
#     def choose_action(self, current_state):
#         if np.random.random() > self.epsilon: #wybieranie eksploatacja -> najlepszy znany ruch
#             #konwersja danych na tensory
#             state = T.tensor([current_state]).to(self.Q_eval.device)

#             #przewidywanie Q-wartości
#             #obliczanie wszystkich mozliwych akcji na podstawie biezacego stanu
#             actions = self.Q_eval.forward(state)
#             action = T.argmax(actions).item()
#         else: #eksploracja -> losowy ruch
#             action = np.random.choice(self.action_space)
#         return action
    
#     def learn(self):
#         if self.memory_counter < self.batch_size:
#             return 
#         self.Q_eval.optimizer.zero_grad()
#         max_mem = min(self.memory_counter, self.mem_size)
#         batch = np.random.choice(max_mem, self.batch_size, replace=False)
#         batch_index = np.arange(self.barch_size, dtype=np.int32)
#         state_batch = T.tensor(self.state_memory[batch]).to(self.Q_eval.device)
#         new_state_batch = T.tensor(self.new_state_memory[batch].to(self.Q_eval.device))
#         reward_batch = T.tensor(self.reward_memory[batch]).to(self.Q_eval.device)
#         terminal_batch = T.tensor(self.terminal_memory[batch]).to(self.Q_eval.device)

#         action_batch = self.action_memory[batch]
#         q_eval = self.Q_eval.forward(state_batch)[batch_index, action_batch]
#         q_next = self.Q_eval.forward(new_state_batch)
#         q_next[terminal_batch] = 0.0

#         q_target = reward_batch + self.gamma * T.max(q_next, dim=1)[0]

#         loss = self.Q_eval.loss(q_target, q_eval).to(self.Q_eval.device)
#         loss.backward()
#         self.Q_eval.optimizer.step()

#         self.epsilon = self.epsilon - self.eps_dec if self.epsilon > self.eps_min else self.eps.min

    

