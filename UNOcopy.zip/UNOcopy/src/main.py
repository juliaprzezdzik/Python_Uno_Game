from GameInterface import start_menu, run

if __name__ == "__main__":
    start_menu()
    run()
